<?php
// this value needs to be set to true to trigger changes in the welcome page
$isReturningUser = true;
require '../../Code/Welcome.php';
